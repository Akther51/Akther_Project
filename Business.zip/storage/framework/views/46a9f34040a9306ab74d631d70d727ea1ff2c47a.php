<?php $__env->startSection('title'); ?>
    EasyWeb
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('front.body.modal-content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('front.body.banner-bottom', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('front.body.skills-content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('front.body.container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('front.body.news-content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('front.body.events-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>