<div class="banner-bottom-icons">
    <div class="col-md-6 w3_banner_bottom_icons_left">

        <div class="w3_agile_banner_bottom">
            <a href="#" class="hvr-rectangle-out">
                <h5 class="grow">Grow Your business</h5>
                <img src="<?php echo e(asset('/front')); ?>/images/banner4.jpg" alt=" " class="img-responsive hvr-radial-in" />
            </a>
        </div>
    </div>
    <div class="col-md-6 w3_banner_bottom_icons_left">
        <div class="w3_agile_banner_bottom">
            <h5 class="grow">Grow Your business</h5>
            <a href="#" class="hvr-rectangle-out"><img src="<?php echo e(asset('/front')); ?>/images/banner2.jpg" alt=" " class="img-responsive hvr-radial-in" /></a>
        </div>
    </div>
    <div class="clearfix"> </div>
</div>

<div class="skills">
    <div class="container">
        <h3 class="tittle_agile_w3">Our Skills</h3>
        <div class="heading-underline">
            <div class="h-u1"></div>
            <div class="h-u2"></div>
            <div class="h-u3"></div>
            <div class="clearfix"></div>
        </div>
        <div class="why-choose-agile-grids-top">
            <div class="col-md-6 skills_img_agile">
                <h4>Modern business Template</h4>
                <p>Lorem ipsum magna, vehicula ut.Curabitur nec purus eget urna pulvinar placerat. Integer varius est vitae iaculis suscipit.
                    Integer sed rutrum lectus.Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit.</p>

                <div class="read">
                    <a href="#" class="view resw3" data-toggle="modal" data-target="#myModal">Read More</a>
                </div>
            </div>
            <div class="col-md-6 services_bottom_grid_right">

                <div class='bar_group'>
                    <div class='bar_group__bar thin elastic' label='Graphic Design' value='130'></div>
                    <div class='bar_group__bar thin elastic' label='SEO' value='160'></div>
                    <div class='bar_group__bar thin elastic' label='Web Development' value='180'></div>
                    <div class='bar_group__bar thin elastic' label='Web Design' value='230'></div>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>