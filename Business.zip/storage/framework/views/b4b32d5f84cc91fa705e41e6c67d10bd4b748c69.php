<!DOCTYPE html>
<html>

    
    
    

    
    

    

    
    

<body>
    <div id="app">
        
            
                

                    
                    
                        
                        
                        
                        
                    

                    
                    
                        
                    
                

                
                    
                    
                        
                    

                    
                    
                        
                        
                            
                            
                        
                            
                                
                                    
                                

                                
                                    
                                        
                                            
                                                     
                                            
                                        

                                        
                                            
                                        
                                    
                                
                            
                        
                    
                
            
        

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    
</body>
</html>
