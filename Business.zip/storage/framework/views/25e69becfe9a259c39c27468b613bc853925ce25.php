
<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('front.asset.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<?php echo $__env->make('front.header.navber', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('body'); ?>
<?php echo $__env->make('front.footer.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('front.asset.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>