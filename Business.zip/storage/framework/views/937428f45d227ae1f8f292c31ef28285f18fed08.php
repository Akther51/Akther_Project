<div class="agileits_top_menu">

    <div class="w3l_header_left">
        <ul>
            <li><i class="fa fa-map-marker" aria-hidden="true"></i> 1000,Dhaka,Bangladesh</li>
            <li><i class="fa fa-phone" aria-hidden="true"></i> +(880)1824910451</li>
            <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:info@example.com">akther0451@gmail.com</a></li>
        </ul>
    </div>
    <div class="w3l_header_right">
        <div class="w3ls-social-icons text-left">
            <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
            <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
            <a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>
            <a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a>
        </div>
    </div>
    <div class="clearfix"> </div>
</div>
<div class="agileits_w3layouts_banner_nav">
    <nav class="navbar navbar-default">
        <div class="navbar-header navbar-left">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <h1><a class="navbar-brand" href="index.html"><i class="fa fa-crosshairs" aria-hidden="true"></i>EasyWeb</a></h1>

        </div>
        <ul class="agile_forms">
            <li><a class="active" href="<?php echo e(url('/login')); ?>" data-toggle="" data-target="#">Login</a> </li>
            <li><a href="<?php echo e(url('/register')); ?>" data-toggle="" data-target="">Register</a> </li>
        </ul>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
            <nav>
                <ul class="nav navbar-nav">
                    <li class="active"><a href="<?php echo e(url('/')); ?>" class="hvr-underline-from-center">Home</a></li>
                    <li><a href="<?php echo e(url('/front/menu/about-content')); ?>" class="hvr-underline-from-center">About</a></li>
                    <li><a href="<?php echo e(url('/front/menu/portfolio-content')); ?>" class="hvr-underline-from-center">Portfolio</a></li>
                    <li><a href="<?php echo e(url('/front/menu/blog-content')); ?>" class="hvr-underline-from-center">Blog</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle hvr-underline-from-center" data-toggle="dropdown">Short Codes <b class="fa fa-caret-down"></b></a>
                        <ul class="dropdown-menu agile_short_dropdown">
                            <li><a href="<?php echo e(url('/front/menu/icon-content')); ?>">Web Icons</a></li>
                            <li><a href="<?php echo e(url('/front/menu/typography')); ?>">Typography</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('/front/menu/contact')); ?>" class="hvr-underline-from-center">Contact</a></li>
                </ul>
            </nav>

        </div>
    </nav>

    <div class="clearfix"> </div>
</div>