<?php $__env->startSection('title'); ?>
    About
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <!-- Modal1 --
    =================
    <!-- //Modal2 -->
    <!-- /agile_inner_banner_info -->
    <div class="agile_inner_banner_info">
        <h2>About </h2>
        <p>Add Some Short Description</p>
    </div>
    <!-- //agile_inner_banner_info -->
    <!-- about -->
    <div class="services">
        <div class="container">
            <div class="col-md-6 w3layouts_about_grid_left">
                <div class="w3_about_grid">
                    <img src="<?php echo e(asset('/front')); ?>/images/4.jpg" alt=" " class="img-responsive" />
                </div>
                <div class="col-md-6 w3layouts_about_grid_left1">
                    <img src="<?php echo e(asset('/front')); ?>/images/1.jpg" alt=" " class="img-responsive" />
                </div>
                <div class="col-md-6 w3layouts_about_grid_left1">
                    <img src="<?php echo e(asset('/front')); ?>/images/5.jpg" alt=" " class="img-responsive" />
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="col-md-6 w3layouts_about_grid_right">
                <h3>Aenean facilisis erat posuere erat ornare ultrices.</h3>
                <p class="w3_turpis_para">Nulla tincidunt arcu sed gravida lacinia. In eleifend,
                    ipsum imperdiet ullamcorper facilisis, dolor diam fermentum neque, eu efficitur
                    velit elit fringilla magna.Nunc a urna turpis..</p>
                <div class="w3layouts_about_grid_right_grids">
                    <div class="w3layouts_about_grid_right_grid">
                        <div class="col-xs-3 w3layouts_about_grid_right_grid1l">
                            <div class="w3layouts_about_grid_right_grid1l_1">
                                <i class="fa fa-bullhorn" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="col-xs-9 w3layouts_about_grid_right_grid1r">
                            <h4>Nulla tincidunt arcu sed</h4>
                            <p>Aenean vestibulum elementum nisi.Mauris luctus massa ipsum.</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="w3layouts_about_grid_right_grid">
                        <div class="col-xs-3 w3layouts_about_grid_right_grid1l">
                            <div class="w3layouts_about_grid_right_grid1l_1">
                                <i class="fa fa-window-restore" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="col-xs-9 w3layouts_about_grid_right_grid1r">
                            <h4>Commodo nisi scelerisque</h4>
                            <p>Aenean vestibulum elementum nisi.Mauris luctus massa ipsum..</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="w3layouts_about_grid_right_grid">
                        <div class="col-xs-3 w3layouts_about_grid_right_grid1l">
                            <div class="w3layouts_about_grid_right_grid1l_1">
                                <i class="fa fa-cubes" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="col-xs-9 w3layouts_about_grid_right_grid1r">
                            <h4>Mauris luctus massa ipsum</h4>
                            <p>Aenean vestibulum elementum nisi.Mauris luctus massa ipsum.</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
    <!-- //about -->
    <!-- about-bottom -->
    <div class="about-bottom">
        <div class="col-md-6 w3l_about_bottom_left">
            <img src="<?php echo e(asset('/front')); ?>/images/10.jpg" alt=" " class="img-responsive" />
            <a class="play-icon popup-with-zoom-anim" href="#small-dialog">
                <i class="fa fa-play-circle-o" aria-hidden="true"></i>
            </a>
            <div class="w3l_about_bottom_left_video">
                <h4>Watch our video</h4>
            </div>
        </div>
        <div class="col-md-6 w3l_about_bottom_right">
            <h3 class="tittle_agile_w3 why">Why Choose US</h3>
            <div class="heading-underline">
                <div class="h-u1"></div><div class="h-u2"></div><div class="h-u3"></div><div class="clearfix"></div>
            </div>
            <div class="panel-group w3l_panel_group_faq" id="accordion" role="tablist" aria-multiselectable="true">
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title asd">
                            <a class="pa_italic" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <span class="glyphicon glyphicon-plus" aria-hidden="true"></span><i class="glyphicon glyphicon-minus" aria-hidden="true"></i>assumenda est cliche quia
                            </a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body panel_text">
                            Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia.
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingTwo">
                        <h4 class="panel-title asd">
                            <a class="pa_italic collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                <span class="glyphicon glyphicon-plus" aria-hidden="true"></span><i class="glyphicon glyphicon-minus" aria-hidden="true"></i>Itaque earum rerum
                            </a>
                        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                        <div class="panel-body panel_text">
                            Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia.
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingThree">
                        <h4 class="panel-title asd">
                            <a class="pa_italic collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                <span class="glyphicon glyphicon-plus" aria-hidden="true"></span><i class="glyphicon glyphicon-minus" aria-hidden="true"></i>autem accusamus terry sed
                            </a>
                        </h4>
                    </div>
                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                        <div class="panel-body panel_text">
                            Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia.
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"> </div>
    </div>
    <!-- //about-bottom -->

    <!-- choose-us -->
    <?php echo $__env->make('front.body.container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- //choose-us -->
    <!-- team -->
    <div class="services">
        <div class="container">
            <h3 class="tittle_agile_w3">Amazing Team</h3>
            <div class="heading-underline">
                <div class="h-u1"></div><div class="h-u2"></div><div class="h-u3"></div><div class="clearfix"></div>
            </div>
            <div class="w3_services_grids">
                <div class="col-md-3 w3ls_team_grid">
                    <div class="w3ls_team_grid1 hover15">
                        <figure>
                            <img src="<?php echo e(asset('/front')); ?>/images/11.jpg" alt=" " class="img-responsive" />
                        </figure>
                        <div class="w3ls_team_grid1_pos">
                            <ul class="social-icons">
                                <li><a href="#" class="icon icon-border facebook"></a></li>
                                <li><a href="#" class="icon icon-border twitter"></a></li>
                                <li><a href="#" class="icon icon-border instagram"></a></li>
                            </ul>
                        </div>
                    </div>
                    <h4>French Carl</h4>
                    <p>Ceo</p>
                </div>
                <div class="col-md-3 w3ls_team_grid">
                    <div class="w3ls_team_grid1 hover15">
                        <figure>
                            <img src="<?php echo e(asset('/front')); ?>/images/14.jpg" alt=" " class="img-responsive" />
                        </figure>
                        <div class="w3ls_team_grid1_pos">
                            <ul class="social-icons">
                                <li><a href="#" class="icon icon-border twitter"></a></li>
                                <li><a href="#" class="icon icon-border instagram"></a></li>
                                <li><a href="#" class="icon icon-border facebook"></a></li>
                            </ul>
                        </div>
                    </div>
                    <h4>Peter Williamson</h4>
                    <p>Manager</p>
                </div>
                <div class="col-md-3 w3ls_team_grid">
                    <div class="w3ls_team_grid1 hover15">
                        <figure>
                            <img src="<?php echo e(asset('/front')); ?>/images/13.jpg" alt=" " class="img-responsive" />
                        </figure>
                        <div class="w3ls_team_grid1_pos">
                            <ul class="social-icons">
                                <li><a href="#" class="icon icon-border instagram"></a></li>
                                <li><a href="#" class="icon icon-border facebook"></a></li>
                                <li><a href="#" class="icon icon-border twitter"></a></li>
                            </ul>
                        </div>
                    </div>
                    <h4>Laura James</h4>
                    <p>Director</p>
                </div>
                <div class="col-md-3 w3ls_team_grid">
                    <div class="w3ls_team_grid1 hover15">
                        <figure>
                            <img src="<?php echo e(asset('/front')); ?>/images/12.jpg" alt=" " class="img-responsive" />
                        </figure>
                        <div class="w3ls_team_grid1_pos">
                            <ul class="social-icons">
                                <li><a href="#" class="icon icon-border pinterest"></a></li>
                                <li><a href="#" class="icon icon-border twitter"></a></li>
                                <li><a href="#" class="icon icon-border instagram"></a></li>
                            </ul>
                        </div>
                    </div>
                    <h4>Rosy Paul</h4>
                    <p>Hr</p>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>