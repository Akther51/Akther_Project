<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<?php echo $__env->make('admin.asset.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<section id="container">
    <!--header start-->
    <?php echo $__env->make('admin.header.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--header end-->
    <!--sidebar start-->
    <?php echo $__env->make('admin.side-menu.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <!-- //market-->
            <?php echo $__env->yieldContent('body'); ?>
        </section>
        <!-- footer -->
        <div class="footer">
            <div class="wthree-copyright">
                <p>© 2017 Visitors. All rights reserved | Design by <a href="http://w3layouts.com">Akther Hossain</a></p>
            </div>
        </div>
        <!-- / footer -->
    </section>
    <!--main content end-->
</section>
<?php echo $__env->make('admin.asset.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- //calendar -->
</body>
</html>
