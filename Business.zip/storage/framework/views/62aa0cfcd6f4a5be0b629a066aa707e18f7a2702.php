
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- custom-theme -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Treasurer Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript">
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- //custom-theme -->
    <link href="<?php echo e(asset('/front')); ?>/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo e(asset('/front')); ?>/css/slicebox.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/front')); ?>/css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo e(asset('/front')); ?>/css/blog.css" rel="stylesheet" type="text/css" media="all" />
    <!-- font-awesome-icons -->
    <link href="<?php echo e(asset('/front')); ?>/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo e(asset('/front')); ?>/fonts/glyphicons-halflings-regular.svg" rel="stylesheet">
    <!-- //font-awesome-icons -->
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic'
          rel='stylesheet' type='text/css'>
    <link href="//fonts.googleapis.com/css?family=Raleway:100i,200,200i,300,400,500,500i,600,700,700i,800,800i" rel="stylesheet">

</head>
