<?php $__env->startSection('title'); ?>
    Contact US
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                    <div class="signin-form profile">
                        <h3 class="agileinfo_sign">Sign In</h3>
                        <div class="login-form">
                            <form action="#" method="post">
                                <input type="email" name="email" placeholder="E-mail" required="">
                                <input type="password" name="password" placeholder="Password" required="">
                                <div class="tp">
                                    <input type="submit" value="Sign In">
                                </div>
                            </form>
                        </div>
                        <div class="login-social-grids">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-rss"></i></a></li>
                            </ul>
                        </div>
                        <p><a href="#" data-toggle="modal" data-target="#myModal3" > Don't have an account?</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //Modal1 -->
    <!-- Modal2 -->
    <div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                    <div class="signin-form profile">
                        <h3 class="agileinfo_sign">Sign Up</h3>
                        <div class="login-form">
                            <form action="#" method="post">
                                <input type="text" name="name" placeholder="Username" required="">
                                <input type="email" name="email" placeholder="Email" required="">
                                <input type="password" name="password" id="password1" placeholder="Password" required="">
                                <input type="password" name="password" id="password2" placeholder="Confirm Password" required="">

                                <input type="submit" value="Sign Up">
                            </form>
                        </div>
                        <p><a href="#"> By clicking register, I agree to your terms</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //Modal2 -->
    <!-- /agile_inner_banner_info -->
    <div class="agile_inner_banner_info">
        <h2>Contact </h2>
        <p>Add Some Short Description</p>
    </div>
    <!-- //agile_inner_banner_info -->
    <!-- contact -->
    <div class="services">
        <div class="container">
            <div class="w3ls_address_mail_footer_grids">
                <div class="col-md-4 w3ls_footer_grid_left con">
                    <div class="wthree_footer_grid_left">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                    </div>
                    <p>3481 Melrose Place, Beverly Hills, <span>New York City 90210.</span></p>
                </div>
                <div class="col-md-4 w3ls_footer_grid_left con">
                    <div class="wthree_footer_grid_left">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                    </div>
                    <p>+(000) 123 4565 32 <span>+(010) 123 4565 35</span></p>
                </div>
                <div class="col-md-4 w3ls_footer_grid_left con">
                    <div class="wthree_footer_grid_left">
                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                    </div>
                    <p><a href="mailto:info@example.com">info@example1.com</a>
                        <span><a href="mailto:info@example.com">info@example2.com</a></span></p>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <div class="agileits_map">
        <div class="container">
            <h3 class="tittle_agile_w3">Find Us</h3>
            <div class="heading-underline">
                <div class="h-u1"></div><div class="h-u2"></div><div class="h-u3"></div><div class="clearfix"></div>
            </div>
        </div>
        <div class="w3_services_grids">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387142.84010033106!2d-74.25819252532891!3d40.70583163828471!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sin!4v1475140387172" style="border:0"></iframe>
        </div>
    </div>
    <div class="services">
        <div class="container">
            <h3 class="tittle_agile_w3">Send Us Message</h3>
            <div class="heading-underline">
                <div class="h-u1"></div><div class="h-u2"></div><div class="h-u3"></div><div class="clearfix"></div>
            </div>
            <div class="agileinfo_mail_grids">
                <form action="#" method="post">
					<span class="input input--chisato">
						<input class="input__field input__field--chisato" name="Name" type="text" id="input-13" placeholder=" " required="" />
						<label class="input__label input__label--chisato" for="input-13">
							<span class="input__label-content input__label-content--chisato" data-content="Name">Name</span>
						</label>
					</span>
                    <span class="input input--chisato">
						<input class="input__field input__field--chisato" name="Email" type="email" id="input-14" placeholder=" " required="" />
						<label class="input__label input__label--chisato" for="input-14">
							<span class="input__label-content input__label-content--chisato" data-content="Email">Email</span>
						</label>
					</span>
                    <span class="input input--chisato">
						<input class="input__field input__field--chisato" name="Subject" type="text" id="input-15" placeholder=" " required="" />
						<label class="input__label input__label--chisato" for="input-15">
							<span class="input__label-content input__label-content--chisato" data-content="Subject">Subject</span>
						</label>
					</span>
                    <textarea name="Message" placeholder="Your comment here..." required=""></textarea>
                    <input type="submit" value="Submit">
                </form>
            </div>
        </div>
    </div>
    <!-- //contact -->


    <!-- footer -->
    <div class="footer">
        <div class="container">
            <div class="w3_agile_footer_grids">
                <div class="col-md-4 w3_agile_footer_grid">
                    <h3>Latest Tweets</h3>
                    <ul class="agile_footer_grid_list">
                        <li><i class="fa fa-twitter" aria-hidden="true"></i>Nam libero tempore, cum soluta nobis est eligendi optio
                            cumque nihil impedit. <span>1 day ago</span></li>
                        <li><i class="fa fa-twitter" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus <a href="mailto:info@mail.com">info@mail.com</a>
                            cumque nihil impedit. <span>2 days ago</span></li>
                    </ul>
                </div>
                <div class="col-md-4 w3_agile_footer_grid">
                    <h3>Navigation</h3>
                    <ul class="agileits_w3layouts_footer_grid_list">
                        <li><i class="fa fa-angle-double-right" aria-hidden="true"></i><a href="index.html">Home</a></li>
                        <li><i class="fa fa-angle-double-right" aria-hidden="true"></i><a href="about.html">About</a></li>
                        <li><i class="fa fa-angle-double-right" aria-hidden="true"></i><a href="portfolio.html">Portfolio</a></li>
                        <li><i class="fa fa-angle-double-right" aria-hidden="true"></i><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4 w3_agile_footer_grid">
                    <h3>Instagram Posts</h3>
                    <div class="w3_agileits_footer_grid_left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            <img src="<?php echo e(asset('/front')); ?>/images/f1.jpg" alt=" " class="img-responsive" />
                        </a>
                    </div>
                    <div class="w3_agileits_footer_grid_left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            <img src="<?php echo e(asset('/front')); ?>/images/f2.jpg" alt=" " class="img-responsive" />
                        </a>
                    </div>
                    <div class="w3_agileits_footer_grid_left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            <img src="<?php echo e(asset('/front')); ?>/images/f4.jpg" alt=" " class="img-responsive" />
                        </a>
                    </div>
                    <div class="w3_agileits_footer_grid_left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            <img src="<?php echo e(asset('/front')); ?>/images/f3.jpg" alt=" " class="img-responsive" />
                        </a>
                    </div>
                    <div class="w3_agileits_footer_grid_left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            <img src="<?php echo e(asset('/front')); ?>/images/f1.jpg" alt=" " class="img-responsive" />
                        </a>
                    </div>
                    <div class="w3_agileits_footer_grid_left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            <img src="<?php echo e(asset('/front')); ?>/images/f2.jpg" alt=" " class="img-responsive" />
                        </a>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="w3ls_address_mail_footer_grids">
                <div class="col-md-4 w3ls_footer_grid_left">
                    <div class="wthree_footer_grid_left">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                    </div>
                    <p>3481 Melrose Place, Beverly Hills, <span>New York City 90210.</span></p>
                </div>
                <div class="col-md-4 w3ls_footer_grid_left">
                    <div class="wthree_footer_grid_left">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                    </div>
                    <p>+(000) 123 4565 32 <span>+(010) 123 4565 35</span></p>
                </div>
                <div class="col-md-4 w3ls_footer_grid_left">
                    <div class="wthree_footer_grid_left">
                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                    </div>
                    <p><a href="mailto:info@example.com">info@example1.com</a>
                        <span><a href="mailto:info@example.com">info@example2.com</a></span></p>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="agileinfo_copyright">
                <p>© 2017 Treasurer. All Rights Reserved | Design by <a href="https://w3layouts.com/">W3layouts</a></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>