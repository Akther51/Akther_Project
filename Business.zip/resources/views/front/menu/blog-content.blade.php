@extends('front.master')
@section('title')
    Blog
@endsection
@section('body')
    <div class="agile_inner_banner_info">
        <h2>Blog </h2>
        <p>Add Some Short Description</p>
    </div>
    <!-- //agile_inner_banner_info -->
    <!-- blog -->
    <div class="services">
        <div class="container">
            <div class="col-md-8 event-left w3-agile-event-left">
                <div class="event-left1 w3-agile-event-left1">
                    <div class="col-xs-6 event-left1-left agile-event-left1-left">
                        <a href="single.html"><img src="{{asset('/front')}}/images/7.jpg" alt=" " class="img-responsive" /></a>
                        <div class="event-left1-left-pos agileits-w3layouts-event-left1-left-pos">
                            <ul>
                                <li><a href="#"><span class="fa fa-tags" aria-hidden="true"></span>5 Tags</a></li>
                                <li><a href="#"><span class="fa fa-heart-o" aria-hidden="true"></span>200 Likes</a></li>
                                <li><a href="#"><span class="fa fa-user" aria-hidden="true"></span> Leo Paul</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-6 event-left1-right w3-agileits-event-left1-right">
                        <h4>2nd / May 2017</h4>
                        <h5><a href="single.html">consectetur adipiscing elit, sed do eiusmod</a></h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="event-left1 w3-agile-event-left1">
                    <div class="col-xs-6 event-left1-right event-left1-right-dummy wthree-event-left1-right">
                        <h4>5th / May 2017</h4>
                        <h5><a href="single.html">Sed ut perspiciatis unde omnis iste natus error sit voluptatem</a></h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
                    </div>
                    <div class="col-xs-6 event-left1-left agileinfo-event-left1-left">
                        <a href="single.html"><img src="{{asset('/front')}}/images/6.jpg" alt=" " class="img-responsive" /></a>
                        <div class="event-left1-left-pos agileits-event-left1-left-pos">
                            <ul>
                                <li><a href="#"><span class="fa fa-tags" aria-hidden="true"></span>6 Tags</a></li>
                                <li><a href="#"><span class="fa fa-heart-o" aria-hidden="true"></span>160 Likes</a></li>
                                <li><a href="#"><span class="fa fa-user" aria-hidden="true"></span>Michael</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="event-left1 w3-agile-event-left1">
                    <div class="col-xs-6 event-left1-left w3ls-event-left1-left">
                        <a href="single.html"><img src="{{asset('/front')}}/images/4.jpg" alt=" " class="img-responsive" /></a>
                        <div class="event-left1-left-pos w3l-event-left1-left-pos">
                            <ul>
                                <li><a href="#"><span class="fa fa-tags" aria-hidden="true"></span>7 Tags</a></li>
                                <li><a href="#"><span class="fa fa-heart-o" aria-hidden="true"></span>341 Likes</a></li>
                                <li><a href="#"><span class="fa fa-user" aria-hidden="true"></span>Richard</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-6 event-left1-right w3-event-left1-right">
                        <h4>8th / May 2017</h4>
                        <h5><a href="single.html">Neque porro quisquam est, qui dolorem ipsum quia dolor</a></h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="event-left1 w3-agile-event-left1">
                    <div class="col-xs-6 event-left1-right event-left1-right-dummy w3layouts-event-left1-right">
                        <h4>11th / May 2017</h4>
                        <h5><a href="single.html">Quis autem vel eum iure ea voluptate velit esse quam</a></h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
                    </div>
                    <div class="col-xs-6 event-left1-left w3-agile-event-left1-left">
                        <a href="single.html"><img src="{{asset('/front')}}/images/5.jpg" alt=" " class="img-responsive" /></a>
                        <div class="event-left1-left-pos agile-event-left1-left-pos">
                            <ul>
                                <li><a href="#"><span class="fa fa-tags" aria-hidden="true"></span>9 Tags</a></li>
                                <li><a href="#"><span class="fa fa-heart-o" aria-hidden="true"></span>432 Likes</a></li>
                                <li><a href="#"><span class="fa fa-user" aria-hidden="true"></span>Thomas</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <nav class="paging1 agileits-w3layouts-paging1">
                    <ul class="pagination paging w3-agileits-paging">
                        <li>
                            <a href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                        <li><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li>
                            <a href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="col-md-4 event-right wthree-event-right">
                <div class="event-right1 agileinfo-event-right1">
                    <div class="search1 agileits-search1">
                        <form action="#" method="post">
                            <input type="search" name="Search" placeholder="Search here..." required="">
                            <input type="submit" value="Send">
                        </form>
                    </div>
                    <div class="categories w3ls-categories">
                        <h3>Categories</h3>
                        <ul>
                            <li><i class="fa fa-check" aria-hidden="true"></i><a href="single.html">At vero eos et accusamus iusto</a></li>
                            <li><i class="fa fa-check" aria-hidden="true"></i><a href="single.html">Sed ut perspiciatis unde omnis</a></li>
                            <li><i class="fa fa-check" aria-hidden="true"></i><a href="single.html">Accusantium doloremque lauda</a></li>
                            <li><i class="fa fa-check" aria-hidden="true"></i><a href="single.html">Vel illum qui dolorem fugiat quo</a></li>
                            <li><i class="fa fa-check" aria-hidden="true"></i><a href="single.html">Quis autem vel eum reprehenderit</a></li>
                            <li><i class="fa fa-check" aria-hidden="true"></i><a href="single.html">Neque porro quisquam est qui</a></li>
                        </ul>
                    </div>
                    <div class="posts w3l-posts">
                        <h3>Our Events</h3>
                        <div class="posts-grids w3-posts-grids">
                            <div class="posts-grid w3-posts-grid">
                                <div class="posts-grid-left w3-posts-grid-left">
                                    <a href="single.html"><img src="{{asset('/front')}}/images/1.jpg" alt=" " class="img-responsive" /></a>
                                </div>
                                <div class="posts-grid-right w3-posts-grid-right">
                                    <h4><a href="single.html">Sed ut perspiciatis unde omnis iste natus</a></h4>
                                    <ul class="wthree_blog_events_list">
                                        <li><i class="fa fa-calendar" aria-hidden="true"></i>10/5/2017</li>
                                        <li><i class="fa fa-user" aria-hidden="true"></i><a href="single.html">Admin</a></li>
                                    </ul>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <div class="posts-grid w3-posts-grid">
                                <div class="posts-grid-left w3-posts-grid-left">
                                    <a href="single.html"><img src="{{asset('/front')}}/images/6.jpg" alt=" " class="img-responsive" /></a>
                                </div>
                                <div class="posts-grid-right w3-posts-grid-right">
                                    <h4><a href="single.html">Neque porro quisquam qui dolorem</a></h4>
                                    <ul class="wthree_blog_events_list">
                                        <li><i class="fa fa-calendar" aria-hidden="true"></i>12/5/2017</li>
                                        <li><i class="fa fa-user" aria-hidden="true"></i><a href="single.html">Admin</a></li>
                                    </ul>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <div class="posts-grid w3-posts-grid">
                                <div class="posts-grid-left w3-posts-grid-left">
                                    <a href="single.html"><img src="{{asset('/front')}}/images/7.jpg" alt=" " class="img-responsive" /></a>
                                </div>
                                <div class="posts-grid-right w3-posts-grid-right">
                                    <h4><a href="single.html">Nemo enim ipsam voluptatem quia</a></h4>
                                    <ul class="wthree_blog_events_list">
                                        <li><i class="fa fa-calendar" aria-hidden="true"></i>13/5/2017</li>
                                        <li><i class="fa fa-user" aria-hidden="true"></i><a href="single.html">Admin</a></li>
                                    </ul>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                    </div>
                    <div class="tags tags1 w3layouts-tags">
                        <h3>Recent Tags</h3>
                        <ul>
                            <li><a href="single.html">Designs</a></li>
                            <li><a href="single.html">Growth</a></li>
                            <li><a href="single.html">Latest</a></li>
                            <li><a href="single.html">Price</a></li>
                            <li><a href="single.html">Tools</a></li>
                            <li><a href="single.html">Agile</a></li>
                            <li><a href="single.html">Category</a></li>
                            <li><a href="single.html">Themes</a></li>
                            <li><a href="single.html">Growth</a></li>
                            <li><a href="single.html">Agile</a></li>
                            <li><a href="single.html">Price</a></li>
                            <li><a href="single.html">Tools</a></li>
                            <li><a href="single.html">Business</a></li>
                            <li><a href="single.html">Category</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
@endsection