@extends('front.master')
@section('title')
    Portfolio
@endsection
@section('body')
    <div class="agile_inner_banner_info">
        <h2>Portfolio </h2>
        <p>Add Some Short Description</p>
    </div>
    <!-- //agile_inner_banner_info -->
    <!-- events-top -->
    <div class="services">
        <div class="container">
            <h3 class="tittle_agile_w3">Portfolio</h3>
            <div class="heading-underline">
                <div class="h-u1"></div><div class="h-u2"></div><div class="h-u3"></div><div class="clearfix"></div>
            </div>
            <ul class="portfolio_agile_info_w3ls">
                <li>
                    <div class="agile_events_top_grid">
                        <div class="w3_agileits_evets_text_img">
                            <a href="{{asset('/front')}}/images/4.jpg" class="lsb-preview" data-lsb-group="header">
                                <div class="view view-eighth">
                                    <img src="{{asset('/front')}}/images/4.jpg" alt=" " class="img-responsive" />
                                    <div class="mask">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="agileits_w3layouts_events_text port_info_agile">
                            <h3>EasyWeb</h3>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="agile_events_top_grid">
                        <div class="w3_agileits_evets_text_img">
                            <a href="{{asset('/front')}}/images/7.jpg" class="lsb-preview" data-lsb-group="header">
                                <div class="view view-eighth">
                                    <img src="{{asset('/front')}}/images/7.jpg" alt=" " class="img-responsive" />
                                    <div class="mask">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="agileits_w3layouts_events_text port_info_agile">
                            <h3>EasyWeb</h3>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="agile_events_top_grid">
                        <div class="w3_agileits_evets_text_img">
                            <a href="{{asset('/front')}}/images/6.jpg" class="lsb-preview" data-lsb-group="header">
                                <div class="view view-eighth">
                                    <img src="{{asset('/front')}}/images/6.jpg" alt=" " class="img-responsive" />
                                    <div class="mask">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </div>
                                </div>

                            </a>
                        </div>
                        <div class="agileits_w3layouts_events_text port_info_agile">
                            <h3>EasyWeb</h3>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="agile_events_top_grid">
                        <div class="w3_agileits_evets_text_img">
                            <a href="{{asset('/front')}}/images/5.jpg" class="lsb-preview" data-lsb-group="header">
                                <div class="view view-eighth">
                                    <img src="{{asset('/front')}}/images/5.jpg" alt=" " class="img-responsive" />
                                    <div class="mask">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="agileits_w3layouts_events_text port_info_agile">
                            <h3>EasyWeb</h3>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="agile_events_top_grid">
                        <div class="w3_agileits_evets_text_img">
                            <a href="{{asset('/front')}}/images/1.jpg" class="lsb-preview" data-lsb-group="header">
                                <div class="view view-eighth">
                                    <img src="{{asset('/front')}}/images/1.jpg" alt=" " class="img-responsive" />
                                    <div class="mask">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="agileits_w3layouts_events_text port_info_agile">
                        <h3>EasyWeb</h3>
                    </div>
                </li>
                <li>
                    <div class="agile_events_top_grid">
                        <div class="w3_agileits_evets_text_img">
                            <a href="{{asset('/front')}}/images/1.jpg" class="lsb-preview" data-lsb-group="header">
                                <div class="view view-eighth">
                                    <img src="{{asset('/front')}}/images/8.jpg" alt=" " class="img-responsive" />
                                    <div class="mask">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="agileits_w3layouts_events_text port_info_agile">
                        <h3>EasyWeb</h3>
                    </div>
                </li>
                <li>
                    <div class="agile_events_top_grid">
                        <div class="w3_agileits_evets_text_img">
                            <a href="{{asset('/front')}}/images/4.jpg" class="lsb-preview" data-lsb-group="header">
                                <div class="view view-eighth">
                                    <img src="{{asset('/front')}}/images/4.jpg" alt=" " class="img-responsive" />
                                    <div class="mask">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="agileits_w3layouts_events_text port_info_agile">
                            <h3>EasyWeb</h3>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="agile_events_top_grid">
                        <div class="w3_agileits_evets_text_img">
                            <a href="{{asset('/front')}}/images/7.jpg" class="lsb-preview" data-lsb-group="header">
                                <div class="view view-eighth">
                                    <img src="{{asset('/front')}}/images/7.jpg" alt=" " class="img-responsive" />
                                    <div class="mask">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="agileits_w3layouts_events_text port_info_agile">
                            <h3>EasyWeb</h3>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="agile_events_top_grid">
                        <div class="w3_agileits_evets_text_img">
                            <a href="{{asset('/front')}}/images/6.jpg" class="lsb-preview" data-lsb-group="header">
                                <div class="view view-eighth">
                                    <img src="{{asset('/front')}}/images/6.jpg" alt=" " class="img-responsive" />
                                    <div class="mask">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </div>
                                </div>

                            </a>
                        </div>
                        <div class="agileits_w3layouts_events_text port_info_agile">
                            <h3>EasyWeb</h3>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
@endsection