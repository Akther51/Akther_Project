
<!DOCTYPE html>
<html lang="zxx">
@include('front.asset.head')
<body>
@include('front.header.navber')
@yield('body')
@include('front.footer.footer')
@include('front.asset.script')
</body>
</html>