<div class="banner-bottom">
    <div class="container">
        <div class="mid_agile_bannner_top_info">
            <h2>Let’s made Your own Business</h2>
            <div class="heading-underline">
                <div class="h-u1"></div>
                <div class="h-u2"></div>
                <div class="h-u3"></div>
                <div class="clearfix"></div>
            </div>
            <p>Lorem ipsum dolor sit amet, Lorem ipsum Lorem ipsum.Integer varius est vitae iaculis suscipit. Integer sed rutrum lectus.</p>
        </div>
        <div class="col-md-6 agileits_banner_bottom_left">
            <h3>welcome to <span>EasyWeb</span></h3>
            <p class="w3l_para">Curabitur nec purus eget urna pulvinar placerat. Integer varius est vitae iaculis suscipit. Integer sed rutrum lectus.</p>
            <div class="w3l_social_icons">
                <div class="w3l_social_icon_grid">
                    <div class="w3l_social_icon_gridl w3_facebook">
                        <a href="#">
                            <i class="fa fa-facebook" aria-hidden="true"></i>
                        </a>
                    </div>
                    <div class="w3l_social_icon_gridr">
                        <p class="counter">23,536</p>
                    </div>
                    <div class="clearfix"> </div>
                    <div class="w3l_social_icon_grid_pos">
                        <label>-</label>
                    </div>
                </div>
                <div class="w3l_social_icon_grid w3ls_social_icon_grid">
                    <div class="w3l_social_icon_gridl w3_dribbble">
                        <a href="#">
                            <i class="fa fa-dribbble" aria-hidden="true"></i>
                        </a>
                    </div>
                    <div class="w3l_social_icon_gridr">
                        <p class="counter">13,676</p>
                    </div>
                    <div class="clearfix"> </div>
                    <div class="w3l_social_icon_grid_pos">
                        <label>-</label>
                    </div>
                </div>
                <div class="w3l_social_icon_grid">
                    <div class="w3l_social_icon_gridl w3_instagram">
                        <a href="#">
                            <i class="fa fa-instagram" aria-hidden="true"></i>
                        </a>
                    </div>
                    <div class="w3l_social_icon_gridr">
                        <p class="counter">45,342</p>
                    </div>
                    <div class="clearfix"> </div>
                    <div class="w3l_social_icon_grid_pos">
                        <label>-</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 agileits_banner_bottom_right">
            <div class="w3ls_banner_bottom_right">
                <img src="{{asset('/front')}}/images/2.jpg" alt=" " class="img-responsive" />
                <div class="w3ls_banner_bottom_right_pos">
                    <img src="{{asset('/front')}}/images/1.jpg" alt=" " class="img-responsive" />
                </div>
            </div>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>