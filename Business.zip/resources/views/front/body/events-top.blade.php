<div class="events-top">
    <ul id="flexiselDemo1">
        <li>
            <div class="agile_events_top_grid">
                <div class="w3_agileits_evets_text_img">
                    <a href="{{asset('/front')}}/images/4.jpg" class="lsb-preview" data-lsb-group="header">
                        <div class="view view-eighth">
                            <img src="{{asset('/front')}}/images/4.jpg" alt=" " class="img-responsive" />
                            <div class="mask">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="agile_events_top_grid_pos">
                            <img src="{{asset('/front')}}/images/1.png" alt=" " class="img-responsive" />
                        </div>
                    </a>
                </div>
                <div class="agileits_w3layouts_events_text">
                    <h3>Richard Carl</h3>
                    <p>Client</p>
                </div>
            </div>
        </li>
        <li>
            <div class="agile_events_top_grid">
                <div class="w3_agileits_evets_text_img">
                    <a href="portfolio.html" class="lsb-preview" data-lsb-group="header">
                        <div class="view view-eighth">
                            <img src="{{asset('/front')}}/images/7.jpg" alt=" " class="img-responsive" />
                            <div class="mask">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="agile_events_top_grid_pos">
                            <img src="{{asset('/front')}}/images/3.png" alt=" " class="img-responsive" />
                        </div>
                    </a>
                </div>
                <div class="agileits_w3layouts_events_text">
                    <h3>Michael Crisp</h3>
                    <p>Client</p>
                </div>
            </div>
        </li>
        <li>
            <div class="agile_events_top_grid">
                <div class="w3_agileits_evets_text_img">
                    <a href="portfolio.html" class="lsb-preview" data-lsb-group="header">
                        <div class="view view-eighth">
                            <img src="{{asset('/front')}}/images/6.jpg" alt=" " class="img-responsive" />
                            <div class="mask">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="agile_events_top_grid_pos">
                            <img src="{{asset('/front')}}/images/2.png" alt=" " class="img-responsive" />
                        </div>
                    </a>
                </div>
                <div class="agileits_w3layouts_events_text">
                    <h3>Adam Lii</h3>
                    <p>Client</p>
                </div>
            </div>
        </li>
        <li>
            <div class="agile_events_top_grid">
                <div class="w3_agileits_evets_text_img">
                    <a href="portfolio.html" class="lsb-preview" data-lsb-group="header">
                        <div class="view view-eighth">
                            <img src="{{asset('/front')}}/images/5.jpg" alt=" " class="img-responsive" />
                            <div class="mask">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="agile_events_top_grid_pos">
                            <img src="{{asset('/front')}}/images/4.png" alt=" " class="img-responsive" />
                        </div>
                    </a>
                </div>
                <div class="agileits_w3layouts_events_text">
                    <h3>Thomas Paul</h3>
                    <p>Client</p>
                </div>
            </div>
        </li>
        <li>
            <div class="agile_events_top_grid">
                <div class="w3_agileits_evets_text_img">
                    <a href="portfolio.html" class="lsb-preview" data-lsb-group="header">
                        <div class="view view-eighth">
                            <img src="{{asset('/front')}}/images/1.jpg" alt=" " class="img-responsive" />
                            <div class="mask">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="agile_events_top_grid_pos">
                            <img src="{{asset('/front')}}/images/2.png" alt=" " class="img-responsive" />
                        </div>
                    </a>
                </div>
                <div class="agileits_w3layouts_events_text">
                    <h3>Adam Lii</h3>
                    <p>Client</p>
                </div>
            </div>
        </li>
    </ul>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4>EasyWeb</h4>
                <img src="{{asset('/front')}}/images/banner2.jpg" alt="blog-image" />
                <span>Lorem ipsum dolor sit amet, Sed ut perspiciatis unde omnis iste natus error sit voluptatem , eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.accusantium doloremque laudantium, totam rem aperiamconsectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
            </div>
        </div>
    </div>
</div>
<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                Treasurer
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="col-md-6 w3_modal_body_left">
                        <img src="{{asset('/front')}}/images/2.jpg" alt=" " class="img-responsive" />
                    </div>
                    <div class="col-md-6 w3_modal_body_right">
                        <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi
                            consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.
                            <i>" Quis autem vel eum iure reprehenderit qui in ea voluptate velit
                                esse quam nihil molestiae consequatur.</i></p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </section>
        </div>
    </div>
</div>