<div class="why-choose-agile">
    <div class="container">
        <h3 class="tittle_agile_w3 two">What We Do</h3>
        <div class="heading-underline">
            <div class="h-u1"></div>
            <div class="h-u2"></div>
            <div class="h-u3"></div>
            <div class="clearfix"></div>
        </div>
        <div class="why-choose-agile-grids-top">
            <div class="col-md-4 agileits-w3layouts-grid">
                <div class="wthree_agile_us">
                    <div class="col-xs-3 agile-why-text">
                        <div class="wthree_features_grid">
                            <i class="fa fa-laptop" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="col-xs-9 agile-why-text">
                        <h4>Responsive Layout </h4>
                        <p>Lorem ipsum magna, vehicula ut.</p>
                    </div>

                    <div class="clearfix"> </div>
                </div>
                <div class="wthree_agile_us">
                    <div class="col-xs-3 agile-why-text">
                        <div class="wthree_features_grid">
                            <i class="fa fa-globe" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="col-xs-9 agile-why-text">
                        <h4>Web design</h4>
                        <p>Lorem ipsum magna, vehicula ut.</p>
                    </div>

                    <div class="clearfix"> </div>
                </div>
                <div class="wthree_agile_us">
                    <div class="col-xs-3 agile-why-text">
                        <div class="wthree_features_grid">
                            <i class="fa fa-life-ring" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="col-xs-9 agile-why-text">
                        <h4>Support 24x7 </h4>
                        <p>Lorem ipsum magna, vehicula ut.</p>
                    </div>

                    <div class="clearfix"> </div>
                </div>
            </div>
            <div class="col-md-4 agileits-w3layouts-grid">
                <div class="wthree_agile_us">
                    <div class="col-xs-3 agile-why-text">
                        <div class="wthree_features_grid">
                            <i class="fa fa-folder-open-o" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="col-xs-9 agile-why-text">
                        <h4>Easy Customization</h4>
                        <p>Lorem ipsum magna, vehicula ut.</p>
                    </div>

                    <div class="clearfix"> </div>
                </div>
                <div class="wthree_agile_us">
                    <div class="col-xs-3 agile-why-text">
                        <div class="wthree_features_grid">
                            <i class="fa fa-lightbulb-o" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="col-xs-9 agile-why-text">
                        <h4>Creative Design </h4>
                        <p>Lorem ipsum magna, vehicula ut.</p>
                    </div>

                    <div class="clearfix"> </div>
                </div>
                <div class="wthree_agile_us">
                    <div class="col-xs-3 agile-why-text">
                        <div class="wthree_features_grid">
                            <i class="fa fa-users" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="col-xs-9 agile-why-text">
                        <h4>Easy For Users</h4>
                        <p>Lorem ipsum magna, vehicula ut.</p>
                    </div>

                    <div class="clearfix"> </div>
                </div>
            </div>
            <div class="col-md-4 agileits-w3layouts-grid img">
                <img src="{{asset('/front')}}/images/serve.png" alt=" " class="img-responsive" />
            </div>
            <div class="clearfix"> </div>
        </div>

    </div>
</div>
</div>