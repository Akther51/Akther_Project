<div class="w3l-news-content events">
    <div class="container">
        <h3 class="tittle_agile_w3">Latest News</h3>
        <div class="heading-underline">
            <div class="h-u1"></div>
            <div class="h-u2"></div>
            <div class="h-u3"></div>
            <div class="clearfix"></div>
        </div>
        <div class="w3l-news_info_agile_its">
            <div class="col-md-6 w3l-news">
                <div class="media response-info">
                    <div class="media-left response-text-left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            <img class="media-object" src="{{asset('/front')}}/images/n1.jpg" alt="">
                        </a>
                    </div>
                    <div class="media-body response-text-right">
                        <h5>Conse ctetur adipisi</h5>
                        <ul>
                            <li><i class="fa fa-calendar" aria-hidden="true"></i>May 11, 2017</li>
                            <li><i class="fa fa-users" aria-hidden="true"></i>Followers : 7685</li>
                        </ul>
                        <p>Lorem ipsum dolor sit amet, Lorem ipsum Lorem ipsum.</p>
                        <div class="read">
                            <a href="single.html" class="view resw3">Read More</a>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="media response-info">
                    <div class="media-left response-text-left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            <img class="media-object" src="{{asset('/front')}}/images/n2.jpg" alt="">
                        </a>
                    </div>
                    <div class="media-body response-text-right">
                        <h5>Dolor sit amet</h5>
                        <ul>
                            <li><i class="fa fa-calendar" aria-hidden="true"></i>May 15, 2017</li>
                            <li><i class="fa fa-users" aria-hidden="true"></i>Followers : 2546</li>
                        </ul>
                        <p>Lorem ipsum dolor sit amet, Lorem ipsum Lorem ipsum.</p>
                        <div class="read">
                            <a href="single.html" class="view resw3">Read More</a>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="media response-info">
                    <div class="media-left response-text-left">
                        <a href="#" data-toggle="modal" data-target="#myModal">
                            <img class="media-object" src="{{asset('/front')}}/images/n3.jpg" alt="">
                        </a>
                    </div>
                    <div class="media-body response-text-right">
                        <h5>Sit Lorem ipsum</h5>
                        <ul>
                            <li><i class="fa fa-calendar" aria-hidden="true"></i>May 17, 2017</li>
                            <li><i class="fa fa-users" aria-hidden="true"></i>Followers : 7485</li>
                        </ul>
                        <p>Lorem ipsum dolor sit amet, Lorem ipsum Lorem ipsum.</p>
                        <div class="read">
                            <a href="single.html" class="view resw3">Read More</a>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="col-md-6 wthree_events_grid_right">
                <div class="wthree_events_grid_right1">
                    <h3>News Letter</h3>
                    <p>Never Miss Any Update From Us!</p>
                    <div class="w3layouts_newsletter_right">
                        <form action="#" method="post">
                            <input type="email" name="Email" placeholder="Email..." required="">
                            <input type="submit" value="Subscribe">
                        </form>
                    </div>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>
