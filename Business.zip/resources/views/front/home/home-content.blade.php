@extends('front.master')
@section('title')
    EasyWeb
@endsection

@section('body')
    @include('front.body.modal-content')
    @include('front.body.banner-bottom')
    @include('front.body.skills-content')
    @include('front.body.container')
    @include('front.body.news-content')
    @include('front.body.events-top')
@endsection