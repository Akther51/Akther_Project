@extends('admin.master')
@section('title')
    Dashboard
@endsection
@section('body')
@include('admin.body.main-content')
@endsection